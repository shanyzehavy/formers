#include <stdio.h>
#include "core_api.h"
#include "sim_api.h"

#define BLOCKED 0
#define FG 1
class RR{
public:
    int  num_thrds;
    int  curr_thrd;   // Holds the index of the current thrd running on CPU
    int  *num_of_busy_cyc;
    bool *halts;

    RR(int num_thrds):num_thrds(num_thrds), curr_thrd(0){ // C'tor
        num_of_busy_cyc = new int[num_thrds]();
        halts = new bool[num_thrds]();
        for(int i=0; i<num_thrds ; i++) {
            num_of_busy_cyc[i] = 0;
            halts[i] = false;
        }
    }
    ~RR(){   // D'tor
        delete num_of_busy_cyc;
        delete halts;
    }
    void update_curr_thrd(int min_busy_cyc){
        int curIndex = curr_thrd;
        curr_thrd = (curr_thrd+1)%num_thrds;
        // Thrd is finished (Halt) or busy during the next cycle (load or store) AND thrd index is changing:
        while(((halts[curr_thrd] == true) || (num_of_busy_cyc[curr_thrd] > min_busy_cyc)) && (curr_thrd != curIndex)) 
            curr_thrd = (curr_thrd+1)%num_thrds;
    }

    // Update the number of cycles a thrd is about to be busy
    void init_busy_cyc(int tid, int cyc){
        num_of_busy_cyc[tid] = cyc;
    }

    // Update the remaining busy cycles left to the thrd
    void update_remain_cyc(int cyc){
        for(int i=0; i<num_thrds ; i++) {
            num_of_busy_cyc[i] -= cyc;
            if (num_of_busy_cyc[i] < 0)  // In case cyc > num_of_busy_cyc[i] - reset num_of_busy_cyc[i] to zero (So it won't be negatvie)
                num_of_busy_cyc[i] = 0;
        }
    }
};

class CPU{
public:
    int num_thrds;
    int count_inst;
    int count_cyc;
    int store_cyc;
    int load_cyc;
    int switch_cyc;
    int *next_cmd;
    tcontext *file_reg;  // Regs
    RR rr;

    // C'tor:
    CPU():num_thrds(SIM_GetThreadsNum()), count_inst(0), count_cyc(0), store_cyc(SIM_GetStoreLat()),
              load_cyc(SIM_GetLoadLat()), switch_cyc(SIM_GetSwitchCycles()), rr(num_thrds){
        next_cmd = new int[num_thrds]();
        for(int i=0; i<num_thrds; i++) {
            next_cmd[i] = 0;
        }
        file_reg = new tcontext[num_thrds]();
        for(int i=0; i<num_thrds ; i++) {
            for(int j=0; j<REGS_COUNT;j++) {
                file_reg[i].reg[j] = 0;
            }
        }
    }
    ~CPU(){   // D'tor:
        delete[] next_cmd;
        delete[] file_reg;
    }

};

// Globals: 
static CPU *BlockedMT;
static CPU *FineGrainedMT;

void execute (tcontext *file_reg_, Instruction *inst, int *halts_counter, bool *halts ){
    int value = 0, addr = 0;
    switch (inst->opcode) {
        case CMD_HALT:{
            *halts = true;
            (*halts_counter) += 1;
            break;
        }
        case CMD_LOAD:{   
            addr = file_reg_->reg[inst->src1_index];
            if (inst->isSrc2Imm == true) // In case src2 is an immediate 
                addr += inst->src2_index_imm;
            else // In case src2 is not an immediate - take value from register
                addr += file_reg_->reg[inst->src2_index_imm];
            SIM_MemDataRead(addr, &(file_reg_->reg[inst->dst_index]));
            break;
        }
        case CMD_STORE:{      
            addr = file_reg_->reg[inst->dst_index];
            if (inst->isSrc2Imm == true)
                addr += inst->src2_index_imm;
            else
                addr += file_reg_->reg[inst->src2_index_imm];

            SIM_MemDataWrite(addr, file_reg_->reg[inst->src1_index]);
            break;
        }
        case CMD_SUB: {
            value =  file_reg_->reg[inst->src1_index] - file_reg_->reg[inst->src2_index_imm];
            break;
        }
        case CMD_SUBI:{  
            value =  file_reg_->reg[inst->src1_index] - inst->src2_index_imm;
            break;
        }
        case CMD_ADD:{  
            value =  file_reg_->reg[inst->src1_index] + file_reg_->reg[inst->src2_index_imm];
            break;
        }
        case CMD_ADDI: {
            value =  file_reg_->reg[inst->src1_index] + inst->src2_index_imm;
            break;
        }
        default:{}
    }
    if ((inst->opcode != CMD_LOAD) && (inst->opcode != CMD_STORE) && (inst->opcode != CMD_HALT))
        file_reg_->reg[inst->dst_index] = value;
}
void CORE_BlockedMT() {
    BlockedMT = new CPU();
    Instruction curr_inst;
    int count_halt = 0, tid = BlockedMT->rr.curr_thrd;
    while (count_halt < BlockedMT->num_thrds) {  // Keep loop as long as not all thrds finished
        BlockedMT->count_cyc++;
        if (BlockedMT->rr.num_of_busy_cyc[tid] || BlockedMT->rr.halts[tid]) { // In case thrd is Busy or Halt
            BlockedMT->rr.update_remain_cyc(1); 
            if (BlockedMT->rr.num_of_busy_cyc[tid] || BlockedMT->rr.halts[tid]) { 
                int curTid = tid;
                BlockedMT->rr.update_curr_thrd(BLOCKED);
                tid = BlockedMT->rr.curr_thrd;
                if (tid != curTid) { 
                    BlockedMT->count_cyc += BlockedMT->switch_cyc;   // Add overhead of context switch to the total cycle counter
                    BlockedMT->rr.update_remain_cyc(BlockedMT->switch_cyc);
                }
            }
            continue;
        }
        // In case thrd is ready (Not busy or Halt)
        BlockedMT->rr.update_remain_cyc(1);
        SIM_MemInstRead(BlockedMT->next_cmd[tid], &curr_inst, tid);
        BlockedMT->count_inst++;
        BlockedMT->next_cmd[tid]++;
        execute (&BlockedMT->file_reg[tid], &curr_inst, &count_halt, &BlockedMT->rr.halts[tid]);
        if ((curr_inst.opcode == CMD_LOAD) || (curr_inst.opcode == CMD_STORE) || (curr_inst.opcode == CMD_HALT)) {
            if (curr_inst.opcode == CMD_LOAD) BlockedMT->rr.init_busy_cyc(tid, BlockedMT->load_cyc);
            if (curr_inst.opcode == CMD_STORE) BlockedMT->rr.init_busy_cyc(tid, BlockedMT->store_cyc);
            int curr_tid = tid;
            BlockedMT->rr.update_curr_thrd(BLOCKED);
            tid = BlockedMT->rr.curr_thrd;
            if (tid != curr_tid) {
                BlockedMT->count_cyc += BlockedMT->switch_cyc;
                BlockedMT->rr.update_remain_cyc(BlockedMT->switch_cyc);
            }
            continue;
        }
    }
}

void CORE_FinegrainedMT() {
    FineGrainedMT = new CPU();
    Instruction curr_inst;
    int count_halt = 0, tid = FineGrainedMT->rr.curr_thrd;
    FineGrainedMT->rr.update_curr_thrd(FG);
    while(count_halt < FineGrainedMT->num_thrds) { // As long as not all thrd finished
        FineGrainedMT->count_cyc++;
        if ((FineGrainedMT->rr.num_of_busy_cyc[tid] != 0) || (FineGrainedMT->rr.halts[tid] == true)) {
            tid = FineGrainedMT->rr.curr_thrd;
            FineGrainedMT->rr.update_remain_cyc(1);
            FineGrainedMT->rr.update_curr_thrd(FG);
            continue;
        }
        FineGrainedMT->rr.update_remain_cyc(1);
        SIM_MemInstRead(FineGrainedMT->next_cmd[tid], &curr_inst, tid);
        (FineGrainedMT->next_cmd[tid])++;
        (FineGrainedMT->count_inst)++;
        execute (&FineGrainedMT->file_reg[tid], &curr_inst, &count_halt, &FineGrainedMT->rr.halts[tid]);        
        if ((curr_inst.opcode == CMD_LOAD) || (curr_inst.opcode == CMD_STORE) || (curr_inst.opcode == CMD_HALT))  {
            if (curr_inst.opcode == CMD_LOAD) FineGrainedMT->rr.init_busy_cyc(tid, FineGrainedMT->load_cyc);
            if (curr_inst.opcode == CMD_STORE) FineGrainedMT->rr.init_busy_cyc(tid, FineGrainedMT->store_cyc);
            tid = FineGrainedMT->rr.curr_thrd;
            FineGrainedMT->rr.update_curr_thrd(FG);
            continue;
        }
        tid = FineGrainedMT->rr.curr_thrd;
        FineGrainedMT->rr.update_curr_thrd(FG);
    }
}

double CORE_BlockedMT_CPI(){
    double cpi = 0;
	if(BlockedMT->count_inst != 0){
	   cpi = ((double)BlockedMT->count_cyc) / BlockedMT->count_inst;
	}
	delete BlockedMT;
	return cpi;
}

double CORE_FinegrainedMT_CPI(){
    double cpi = 0;
    if(FineGrainedMT->count_inst != 0){
        cpi = ((double)FineGrainedMT->count_cyc) / FineGrainedMT->count_inst;
    }
    delete FineGrainedMT;
    return cpi;
}

void CORE_BlockedMT_CTX (tcontext* file_reg_, int threadid) {
    for(int i=0 ; i<REGS_COUNT ; i++){
        file_reg_[threadid].reg[i] = BlockedMT->file_reg[threadid].reg[i];
    }
}

void CORE_FinegrainedMT_CTX (tcontext* file_reg_, int threadid) {
    for(int i=0 ; i<REGS_COUNT ; i++){
        file_reg_[threadid].reg[i] = FineGrainedMT->file_reg[threadid].reg[i];
    }
}
