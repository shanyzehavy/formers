#include "dflow_calc.h"
#include <cstdbool>
#include <algorithm>
#include <list>
#include <iostream>
#include <fstream>

using namespace std;
/******** globals ********/
unsigned int num_of_inst;
ofstream out_file; 

class Node_{
    public:
    unsigned int op_time;   // Change form int to something else?
    int depend_arr[2];      // Serial number of the commands
    //int depth;            // Init as dependency entry's depth + 1 ??
    int path_tot_time;      // Change form int to something else?
    int flag;               // Flag counts number of operation that are depending on this operation
    Node_ (): op_time(0), path_tot_time(0){
        for (int i=0; i<2; i++){
            depend_arr[i] = -1;
        }
    }
    Node_ (int op_time_, int depend_arr_[2], int path_tot_time_): op_time(op_time_), path_tot_time(path_tot_time_){
        for (int i=0; i<2; i++){
            depend_arr[i] = depend_arr_[i];
        }
    }
    // No need for D'tor
};

ProgCtx analyzeProg(const unsigned int opsLatency[], const InstInfo progTrace[], unsigned int numOfInsts) {
    // Errros check:
    if( (opsLatency == NULL) || (progTrace == NULL) || (numOfInsts <= 0)){
        return PROG_CTX_NULL;
    }
    out_file.open ("out1.txt");
    int src1, src2, src1_path_time, src2_path_time;
    num_of_inst = numOfInsts; // Save the number of instruction as global
    int find_depend_reg [MAX_OPS] = {-1}; // This array help us find the dependecies according to registers each instuction uses
    Node_ *inst_analyzed = new Node_[num_of_inst /*+ 1*/]();
    for(unsigned int i = 0; i < num_of_inst; ++i){
        src1_path_time = 0, src2_path_time = 0;
        // Find the operation taht used the same regis, or in case of no such op: -1
        inst_analyzed[i].depend_arr[0] = find_depend_reg[progTrace[i].src1Idx]; 
        inst_analyzed[i].depend_arr[1] = find_depend_reg[progTrace[i].src2Idx];
        src1 = inst_analyzed[i].depend_arr[0];
        src2 = inst_analyzed[i].depend_arr[1];
        inst_analyzed[src1].flag++;  // Update the flag of src1 to indicate there is an op depanded on it
        inst_analyzed[src2].flag++;  // Update the flag of src2 to indicate there is an op depanded on it
        find_depend_reg[progTrace[i].dstIdx] = i;
        inst_analyzed[i].op_time = opsLatency[progTrace[i].opcode]; // Update op time
        out_file << "inst_analyzed[i].op_time = " << inst_analyzed[i].op_time << endl;
        if (src1 != -1) { // In case the instruction depends on another one
            src1_path_time = inst_analyzed[src1].path_tot_time + inst_analyzed[src1].op_time;
        }
        if (src2 != -1) { // In case the instruction depends on another one
            src2_path_time = inst_analyzed[src2].path_tot_time + inst_analyzed[src2].op_time;
        }
        out_file << "src1 path time = " << src1_path_time << "src2 path time = " << src2_path_time << endl;
        inst_analyzed[i].path_tot_time = max({src1_path_time, src2_path_time});
        out_file << "inst_analyzed[i].path_tot_time = " << inst_analyzed[i].path_tot_time << endl;
    }

    // // Create a list of the last nodes in the dependencies graph
    // list <Node_*> last_insts;
    // for(unsigned int i = 0; i < num_of_inst; i++){
    //     if(inst_analyzed[i]. flag == false){
    //         last_insts.push_back(&(inst_analyzed[i]));
    //     }
    // }

    return (ProgCtx)inst_analyzed;
}

void freeProgCtx(ProgCtx ctx) {
    delete [] (Node_*)ctx;
}

int getInstDepth(ProgCtx ctx, unsigned int theInst) {
    if ((ctx == NULL) || (theInst < 0) || (theInst > num_of_inst - 1)) // different from bar's check ????
        return -1;
    Node_ *inst_analyzed = (Node_*)ctx;
    return inst_analyzed[(int)theInst].path_tot_time;
}

int getInstDeps(ProgCtx ctx, unsigned int theInst, int *src1DepInst, int *src2DepInst) {
    if ((ctx == NULL) || (theInst < 0) || (theInst > num_of_inst - 1)) // different from bar's check ????
        return -1;
    Node_ *inst_analyzed = (Node_*)ctx;
    *src1DepInst = inst_analyzed[(int)theInst].depend_arr[0];
    *src2DepInst = inst_analyzed[(int)theInst].depend_arr[1];

    return 0;
}

int getProgDepth(ProgCtx ctx) {
    if (ctx == NULL) 
        return -1;
    Node_ *inst_analyzed = (Node_*)ctx;
    int max_path_tot_time = -1, curr_path_tot_time = 0;
    for(unsigned int i = 0; i < num_of_inst; i++){
        if(inst_analyzed[i]. flag == false){ // If the opeartion has no op that depends on it - this is one of the last operations to be executed
            curr_path_tot_time = inst_analyzed[i].path_tot_time + inst_analyzed[i].op_time;
            if (curr_path_tot_time > max_path_tot_time)
                max_path_tot_time = curr_path_tot_time;
        }
    }
    return max_path_tot_time;
}


